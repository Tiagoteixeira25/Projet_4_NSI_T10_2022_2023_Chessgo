# -*- coding: utf-8 -*-
"""
Created on Fri Jan 27 08:16:20 2023

@author: teixeira
"""

from flask import * 

# créer la page html


# créer le plateau


# créer le mouvement des pièces

def mouvement_pion():
    pass
def mouvement_reine():
    pass
def mouvement_roi():
    pass
def mouvement_cavalier():
    pass
def mouvement_fou():
    pass
def mouvement_tour():
    pass



